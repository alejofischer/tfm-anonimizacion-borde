# Bilingual PII NER corpus — Annotation guidelines (v1, agreed 2026-10-01)

Scheme: BIO over character spans. Labels: PER, LOC, ID, FIN, DEMO, CON, CONTACT, and *(v3)* PUB.
Languages: Spanish, English, and mixed ES/EN in one message.

## General rules
- Label only the **value**, never the key or the words around it: `DNI: ⟪ID|12345678Z⟫`, `password=⟪CON|Verano2024!⟫`.
- Label **every occurrence**, including repeats, lower-case, ALL CAPS, misspelled or unaccented forms.
- Spans don't overlap or nest. Adjacent pieces of one thing make one span (full name, full address).
- Don't include surrounding punctuation or quotes in the span (`"Ana"` → `Ana`), but do include internal
  spaces, dashes and dots (`ES91 2100 0418 4502 0005 1332`, `12.345.678-Z`).
- Placeholders and fully masked values are **not** PII: `<API_KEY>`, `XXXX`, `****`, `[NOMBRE]`, `tu_contraseña`.
- **Partially masked** values that still show part of the real value **are** PII and get their label:
  `1234****Z` → ID, `ES91 **** **** **** **** 1332` → FIN, `j***@gmail.com` → CONTACT, `612 *** 678` → CONTACT.
  (Exception: only the last 4 card digits, see FIN.)
- **Broken values are still PII.** Typos, wrong check letters/checksums, OCR errors (`O`↔`0`, `l`↔`1`),
  missing or extra digits, odd spacing, line breaks inside the value, values glued to the previous word
  (`DNI:12345678Z`), emails without `@` or without `.com` (`juan.perezgmail.com`, `juan.perez@gmail`,
  `juan.perez gmail com`): label the whole value as typed, including any line break inside it.
- When in doubt whether something identifies a person, prefer labelling it (recall over precision), but
  never label the hard-negative classes listed under each label.

## PER — person names
- **Label:** first names, surnames, full names, nicknames that refer to a person, initials of a person
  (`J. García`, `JGM`), lower-case names (`habla con marta`), names inside emails' display text, tables and lists.
- **Not PII:** courtesy titles and honorifics (`Sr.`, `Sra.`, `Dr.`, `Dña.`, `Mr.`): `Sr. ⟪PER|García⟫`;
  kinship and role words with no name (`mi madre`, `la abuela`, `Mum`, `el jefe`), and before a name only the
  name is labelled (`tía ⟪PER|Carmen⟫`); usernames and logins (`mgarcia`, `rrhh_admin`);
  company, brand and product names (`Telefónica`, `Mercedes-Benz`); names used as ordinary words
  (`una rosa`, `la luz`, `¡Jesús!`, `will`, `mark the box`); places named after people
  (`calle Isaac Peral` → that's LOC as a whole).
- *(v3)* Well-known people mentioned as public figures are **PUB**, not PER (see PUB below).
  Fictional characters are O (`Don Quijote`, `Harry Potter`, `Sherlock Holmes`).

## PUB — public and historical figures *(v3, 2026-10-13)*
- **Label PUB:** real, well-known people (living or dead) **mentioned in their public role**: history,
  politics, sport, culture, science, business, news. Same span rules as PER (only the name, no titles):
  `¿quién fue ⟪PUB|Napoleón⟫?`, `resume el Quijote de ⟪PUB|Cervantes⟫`, `what did ⟪PUB|Marie Curie⟫ discover?`,
  `estadísticas de ⟪PUB|Messi⟫ esta temporada`, `¿qué dijo ⟪PUB|Pedro Sánchez⟫ ayer en el Congreso?`,
  `write a tweet in the style of ⟪PUB|Taylor Swift⟫`.
- **PER, not PUB:**
  - the same names when they are part of the user's own life or appear with private data:
    `mi jefe se llama ⟪PER|Pedro Sánchez⟫`, `mi vecino ⟪PER|Antonio Machado⟫ me debe ⟪FIN|200 €⟫`,
    `el DNI de ⟪PER|Messi⟫ es ⟪ID|…⟫`;
  - famous names that are also common names when the context doesn't make the public figure clear:
    `he quedado con ⟪PER|Antonio Machado⟫`;
  - people who are only locally or professionally known (a company's CEO in an internal email, a local
    doctor, an influencer you are unsure about), and recently deceased private people.
  - **When in doubt between PER and PUB → PER.**
- **Not PUB:** fictional characters (O); places, prizes, works or companies named after people
  (`calle Isaac Peral` → LOC, `Premio Cervantes`, `Fundación Messi` → O); eponymous diseases
  (`Parkinson`, `Alzheimer` → DEMO when about a specific person, otherwise O).
- **Special-category facts about PUB people:** O for historical (deceased) figures (`⟪PUB|Beethoven⟫ era
  sordo`); for **living** public figures, still label DEMO (`¿⟪PUB|Fulano⟫ tiene ⟪DEMO|cáncer⟫?`),
  because health, religion or orientation stay sensitive even for famous people.
- Why: a living public figure's name is still personal data under GDPR, but discussing their public role is
  low risk. Labelling it PUB (instead of O) keeps the decision in the product's masking policy below, and
  lets us measure PER→PUB confusion as a leak.

## LOC — locations
- **Label:** street addresses (with number, floor, door), postcodes, cities/towns/municipalities,
  provinces/regions — wherever they appear (not only when tied to a person).
  A full address is one span: `⟪LOC|C/ Mayor 12, 3ºB, 28013 Madrid⟫`.
- **Not PII:** countries on their own (`ventas en Francia`) — but countries inside a full address are part of
  the LOC span; names of buildings, offices or company sites (`la sede central`, `Torre Picasso`);
  continents; generic places (`la oficina`, `el hospital`); a city that is part of another name (`Banco Santander`,
  `Seat León`, `Aguas de Valencia`, `Hotel NH Barcelona`, time zone `Europe/Madrid`, office code `Madrid-2`).
  But "the Madrid office", "our Valencia hub", "la oficina de Bilbao" → the city is LOC.

## ID — person-linked identifiers
- **Label:** DNI, NIE, NIF, CIF of a sole trader, passport, social security number (NSS/NAF), tax IDs
  (SSN, TIN, NINO…), driving licence, employee number, customer/member number, patient/medical record
  number (historia clínica), licence plates, contract and insurance policy numbers.
- **Not PII:** ticket/incident numbers, invoice and order numbers, asset/inventory tags, KB/article numbers,
  software versions, UUIDs, commit hashes, product SKUs, registry/file numbers not tied to a person.

## FIN — financial
- **Label:** IBAN, bank account numbers, card numbers, CVV, card expiry when next to a card,
  and **amounts tied to a person**: salary, payslip (nómina), debt, balance, garnishment (embargo),
  bonus, compensation, personal loan/mortgage amounts, refunds or deposits owed to/by a specific person
  (`el reembolso de ⟪FIN|429 €⟫ a su cuenta`, `you still owe me ⟪FIN|80 €⟫`).
- **Not PII:** the last 4 digits of a card on their own (`card ending 4471`, `**** 1234`);
  prices of goods/services, invoice totals between companies, budgets, revenue, generic
  amounts, SWIFT/BIC codes (identify a bank, not a person), transaction IDs.

## DEMO — demographic / special-category data
- **Label:** age (`34 años`, `34-year-old`), date of birth, gender/sex when stated as an attribute,
  nationality, ethnicity, marital status, health conditions, diagnoses, disabilities, medications,
  pregnancy, religion, sexual orientation, political or trade-union affiliation (GDPR Art. 9).
- **Not PII:** professions and job titles (`enfermera`, `CTO`), generic dates (meetings, deadlines,
  invoice dates), grammatical gender, nationalities used for things (`cocina italiana`).
- *(v2, 2026-10-05)* **Only when it is about a specific person.** A person is specific when named, or when the
  text talks about one real individual even without a name: `yo`, `mi hijo`, `la paciente`, `un trabajador
  de mi equipo`, `the employee`, `my landlord`. Health, religion etc. said about nobody in particular are
  **not** PII: medical knowledge (`la metformina se usa para la diabetes tipo 2`), policy and legal questions
  (`¿cuántos días de baja por maternidad hay en España?`, `can an employer ask if a candidate is pregnant?`),
  drug leaflets, statistics, hospital and department names on their own (`Hospital La Paz`, `Oncología`),
  religious holidays as dates (`cerramos en Semana Santa`), unions or parties as organisations
  (`CCOO ha convocado huelga`). The attribute name alone is not PII (`el formulario pide la religión`).
- *(v2)* **Health covers:** diagnoses and conditions (physical and mental), symptoms and injuries, disabilities
  and their degree, allergies, medications and doses, treatments, operations, tests and appointments that
  reveal a condition (`mamografía`, `diálisis`, `quimio`), pregnancy, addictions, and leave or adjustments
  whose reason is health (`baja por ansiedad`, `adaptación del puesto por su lesión de espalda`).
  A medical department or specialist tied to a specific patient's visit counts (`su cita en ⟪DEMO|Oncología⟫`).
- *(v2)* **Other special categories:** religion or belief, including practices that reveal it when tied to a
  person (`hace el ⟪DEMO|Ramadán⟫`, `lleva ⟪DEMO|hiyab⟫`, `es ⟪DEMO|católico practicante⟫`); union membership
  or role (`⟪DEMO|afiliada a CCOO⟫`, `⟪DEMO|delegado de UGT⟫`); political affiliation; sexual orientation;
  gender identity (`mujer trans`); ethnicity; nationality; marital and family-law status
  (`divorciada`, `pareja de hecho`, `en proceso de divorcio`).
- *(v2)* **Span:** the phrase that carries the sensitive fact, with its modifiers, without leading articles,
  possessives or the verb: `tiene una ⟪DEMO|cardiopatía isquémica⟫`, `toma ⟪DEMO|sertralina 50 mg⟫`,
  `está ⟪DEMO|embarazada de 32 semanas⟫`, `está de ⟪DEMO|baja por ansiedad⟫`, `⟪DEMO|cáncer de mama en
  tratamiento⟫`. Two facts joined by "y"/"and"/commas are separate spans: `⟪DEMO|EPOC⟫ y ⟪DEMO|obesidad⟫`.

## CON — credentials and secrets
- **Label only the secret value:** passwords, PINs, API keys, access/refresh tokens, JWTs, private key
  blocks, client secrets, Wi-Fi passwords, the password part of a connection string
  (`postgres://admin:⟪CON|s3cr3t⟫@db:5432/app`), Basic-auth credentials.
- **Not PII:** the key name (`API_KEY=`), usernames (unless they are an email/phone → CONTACT), placeholders,
  public hashes, UUIDs, commit SHAs, example values that are obviously dummy (`changeme`, `password123`
  in documentation — label it if it is presented as a real credential).

## CONTACT — email and phone
- **Label:** email addresses, phone/mobile/fax numbers in any format, including obfuscated forms
  (`juan punto perez arroba gmail punto com`, `six four five...`).
- **Not PII:** generic company switchboards are still labelled (we can't tell reliably); web domains and
  URLs without a personal identifier are not.

## Left to regex rules (not model labels)
- **IP addresses** (`83.44.120.9`, IPv6): not labelled by the model (O). They are handled by a regex rule in post-processing.

## Masking policy *(v3, product behaviour — not a labelling rule)*
Labellers always label what the text says; what gets masked is decided here, per customer.

| Label | Masked by default | Configurable | Notes |
|---|---|---|---|
| PER | yes | no | |
| LOC | yes | no | |
| ID | yes | no | |
| FIN | yes | no | amounts only when tied to a person (see FIN) |
| DEMO | yes | no | GDPR Art. 9 special categories: highest risk |
| CON | yes | no | secrets are always masked |
| CONTACT | yes | no | |
| IP (regex) | yes | no | |
| PUB | **no** | yes ("mask public figures") | see the acceptance rule below |

**PUB acceptance rule (post-processing).** A PUB span is left unmasked only if **both** hold:
1. the model predicts PUB (from context), and
2. the name is in the public-figures dictionary (Wikidata, CC0; matched lower-case and without accents,
   including aliases and surnames used alone, e.g. `Messi`, `Cervantes`).

Otherwise the span is treated as PER and masked. Both ways of failing are safe: a famous person missing from
the dictionary only causes a false alarm, never a leak. For the Balanced / Strict thresholds, PUB counts
like O: a token is masked when P(O) + P(PUB) < threshold (0.9 / 0.98), instead of today's P(O) < threshold.

The defaults and the "configurable" column are to be confirmed with whoever is responsible for GDPR
compliance (DPO).
