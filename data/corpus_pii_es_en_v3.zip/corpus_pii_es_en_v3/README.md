# Corpus bilingüe (español / inglés) para detectar datos personales — v3

Corpus de clasificación de tokens para detectar datos personales y secretos en mensajes que se envían a asistentes de
IA generativa, en español, en inglés y mezclados. Construido para el Trabajo Fin de Máster *Comparativa de
arquitecturas ligeras de aprendizaje profundo para la anonimización contextual de texto bilingüe (español-inglés) en el
borde* (Alejandro Fischer González, Máster Universitario en Inteligencia Artificial, UNIR, 2026).

**No contiene datos personales reales**: todos los nombres, documentos, cuentas, datos de salud y contraseñas son
inventados (en los mensajes de OpenAssistant, los nombres propios de los usuarios se sustituyeron por otros inventados).

## Ficheros
| Fichero | Mensajes | Uso |
|---|---|---|
| `train.jsonl` | 75.098 | entrenamiento |
| `val.jsonl` | 4.345 | validación (elegir época, learning rate y profesores) |
| `test_v1.jsonl` | 1.000 | prueba dentro de la distribución |
| `test_long_v1.jsonl` | 150 | textos largos (1.500–3.400 caracteres) |
| `test_v2.jsonl` | 395 | **prueba principal**: redactada frase a frase con ayuda de un asistente de IA, sin las plantillas ni los valores del generador, y revisada; nunca usada para ajustar nada |
| `test_v3.jsonl` | 102 | casos difíciles (personajes públicos, erratas, salud, dinero), redactados del mismo modo |
| `stats.json` | — | estadísticas por conjunto, fuente, idioma y etiqueta |
| `ANNOTATION_GUIDELINES.md` | — | guía de anotación |

Formato de cada línea: `{"id", "text", "entities": [{"start", "end", "label", "text"}], "source", "lang"}` (posiciones en
caracteres de Python; `text[start:end] == entity.text`).

Etiquetas: `PER` (persona), `LOC` (lugar), `ID` (identificador), `FIN` (dato financiero), `DEMO` (dato demográfico o de
categoría especial), `CON` (contraseña o secreto), `CONTACT` (correo o teléfono) y `PUB` (personaje público mencionado
como tema; se etiqueta pero no es un dato que ocultar).

## Composición del entrenamiento
| Fuente (`source`) | Mensajes | Descripción |
|---|---|---|
| `legacy` | 32.343 | frases sintéticas generadas con modelos de lenguaje, depuradas y reetiquetadas con la guía |
| `openpii` | 12.825 | ai4privacy OpenPII-1.5M (español e inglés), adaptado a las etiquetas |
| `augment_broken`, `augment_typos` | 10.000 | copias con valores rotos o parcialmente enmascarados y con erratas |
| `oasst` | 6.499 | mensajes de usuarios de OpenAssistant oasst2, revisados a mano |
| `chat`, `chat_demo`, `chat_pub`, `chat_v3` | 7.602 | mensajes escritos para el trabajo |
| `mix_concat` | 3.000 | mensajes en español e inglés unidos |
| `templates_con` | 2.829 | secretos en código, configuración y prosa |

## Licencias y atribución
- **ai4privacy OpenPII-1.5M**: CC BY 4.0, © Ai Suisse SA / Ai4Privacy —
  https://huggingface.co/datasets/ai4privacy/pii-masking-openpii-1.5m (adaptado: filtrado por idioma y
  etiquetas convertidas a la taxonomía de este corpus).
- **OpenAssistant Conversations (oasst2)**: Apache-2.0 — Köpf et al. (2023), https://huggingface.co/datasets/OpenAssistant/oasst2
  (adaptado: selección de mensajes, nombres sustituidos y etiquetado).
- **Resto del corpus** (frases y mensajes sintéticos, aumentos, anotaciones y guía): CC BY 4.0, Alejandro Fischer González, 2026.
